

print('Hello World')