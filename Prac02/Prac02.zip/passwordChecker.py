print("Please enter a valid password\nYour password must be between 2 and 6 characters, and contain:\n\t1 or more uppercase characters\n\t1 or more lowercase characters\n\t1 or more numbers")
user_input = input(">>> ")

password_status = False
lower_case = False
upper_case = False
number = False
special_characters = False

while password_status is False:
    for character1 in user_input:
        if character1.islower():
            lower_case = True

    for character2 in user_input:
        if character2.isupper():
            upper_case = True

    for character3 in user_input:
        if character3.isdigit():
            number = True

    for character4 in user_input:
        if character4 in "!@#$%^&*()_-=+`~,./o'[]\<>?O{}|":
            special_characters = True

    if lower_case and upper_case and number and special_characters:
        password_status = True

    else:
        print("Invalid Input")
        user_input = input(">>> ")

print("Your {} character password is valid: {}".format(len(user_input), user_input))