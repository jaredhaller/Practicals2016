import random

print(random.randint(5,20))
#Smallest number is 5 and largest is 20
print(random.randrange(3,10,2))
#Smallest number is 3 and largest is 9
print(random.uniform(2.5,5.5))
#Smallest number is 2.5 and largest is 5.5
